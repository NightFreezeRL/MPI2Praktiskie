import React, { useState, useEffect } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Dimensions,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import MapView from 'react-native-maps';
import Constants from 'expo-constants';
import * as Permission from 'expo-permissions';

export default function App() {
  const { status } = Permission.askAsync(Permission.LOCATION);
  const [longitude, setLongitude] = useState();
  const [latitude, setLatitude] = useState();
  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  
  const description = "ASD";

  useEffect(() => {
    function setPosition({ coords: { latitude, longitude } }) {
      setLongitude(longitude);
      setLatitude(latitude);
    }
    navigator.geolocation.getCurrentPosition(setPosition);

    let watcher = navigator.geolocation.watchPosition(
      setPosition,
      (err) => console.error(err),
      { enableHighAccuracy: true }
    );
    return () => {
      navigator.geolocation.clearWatch(watcher);
    };
  });

  const getWeather = async () => {
    try {
      const response = await fetch(
        'https://api.openweathermap.org/data/2.5/weather?lat=57.538050052883804&lon=25.42293537767873&appid=aa07101d05ea58554350a9a848db0b6a'
      );
      const json = await response.json();
      console.log('the data', json);
      setData(json);
    } catch (error) {
      console.log('data');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    getWeather();
  }, []);
  return (
    <View style={styles.container}>
      <View style={{ flex: 1, padding: 24 }}>
        {isLoading ? (
          <ActivityIndicator />
        ) : (
          <View style={styles.top}>
            <Text>{"City: " + data.name}</Text>
            <Text>{"Weather: " + data.weather[0].description}</Text>
            <Text>{"Longitude: " + data.coord.lon}</Text>
            <Text>{"Latitude: " + data.coord.lat}</Text>
            <Text>{"Temperature: " + data.main.temp}</Text>
            <Text>{"Pressure: " + data.main.pressure}</Text>
            <Text>{"Humidity: " + data.main.humidity}</Text>
          </View>
        )}
      </View>
      <MapView style={styles.mapView} showsUserLocation={true}>
        <MapView.Marker
          coordinate={{
            latitude: 57.538050052883804,
            longitude: 25.42293537767873,
          }}
          title={data.name}
          description={description}
        />
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
  },
  mapView: {
    height: Dimensions.get('window').height/1.3,
    width: Dimensions.get('window').width,
  },
  top: {
    flex: 15,
    backgroundColor: "red",
    borderWidth: 2,
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
  }
});
